import React from "react";
import * as styles from "./Main.module.css";

const Main = () => {
  return (
    <>
      <p>Text example</p>
    </>
  );
};

export default Main;
