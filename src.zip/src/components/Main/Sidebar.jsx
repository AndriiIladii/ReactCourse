import React from "react";
import Nav from "../Header/Nav";

const Sidebar = ({ site }) => {
  return (
    <>
      <ul>
        <li>Страница 1</li>
        <li>Страница 2</li>
        <li>Страница 3</li>
      </ul>
    </>
  );
};

export default Sidebar;
